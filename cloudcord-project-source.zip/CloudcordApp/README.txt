Cloudcord Android wrapper

- Projeto Android para compilar em APK.
- Abre a URL HTTPS: https://cloudcord.vertraweb.app
- Android Studio: abra esta pasta e compile com Build > Build APK(s).
- A compilação em nuvem está configurada no workflow do pacote GitHub Builder.

Nota: o APK é apenas o invólucro Android que abre a aplicação web hospedada no domínio. O app depende de o site estar online.
